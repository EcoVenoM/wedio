angular.module('app.routes', ['ionicUIRouter'])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.page5'
      2) Using $state.go programatically:
        $state.go('tabsController.page5');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab3/home
      /page1/tab5/home
  */
  .state('tabsController.page5', {
    url: '/home',
    views: {
      'tab3': {
        templateUrl: 'templates/page5.html',
        controller: 'page5Ctrl'
      },
      'tab5': {
        templateUrl: 'templates/page5.html',
        controller: 'page5Ctrl'
      }
    }
  })

  .state('tabsController.trendingTop3', {
    url: '/page6',
    views: {
      'tab4': {
        templateUrl: 'templates/trendingTop3.html',
        controller: 'trendingTop3Ctrl'
      }
    }
  })

  .state('tabsController.account', {
    url: '/page7',
    views: {
      'tab5': {
        templateUrl: 'templates/account.html',
        controller: 'accountCtrl'
      }
    }
  })

  .state('tabsController.profile', {
    url: '/profile',
    views: {
      'tab5': {
        templateUrl: 'templates/profile.html',
        controller: 'profileCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/tab3/home')


});